
import React from 'react';
import {hasClass} from '../config/utilFunc';
let classNames = require('classnames');

class SelectOptions extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            optionClass: 'hidden',
            currentValue: this.props.value,
            activeOption:0,
            filtered:this.props.list
        };
    }

    toggleOptions(){
        let css =this.state.optionClass=='hidden'?'shown':'hidden';
        this.setState({optionClass: css,searchValue: '',filtered: this.props.list});
    }
    selectOption(item,index){
        this.setState({activeOption: index,optionClass: 'hidden'});
        this.setState({currentValue:  item});
        this.props.changeCustomer(item);
    }
    getCustomers(item ,index){
        let optionClass = classNames({
            'option': true,
            'option--active': this.state.activeOption==index,
        });
        return <li key={index} value={item} onClick={()=>this.selectOption(item,index)} className={optionClass}>{item.toUpperCase()}</li>;

    }
    render(){

        return (
            <div className="customselect"  onClick={()=>this.toggleOptions('para')}>
                <div className='select' >
                    <span className="customselect__value">{this.state.currentValue.toUpperCase()}</span>
                    {(this.state.filtered && this.state.filtered.length) ? (
                        <ul ref="options" className={this.state.optionClass}>
                            {this.state.filtered.map(this.getCustomers.bind(this))}
                        </ul>)
                        : ''
                    }
                </div>

            </div>
        );
    }
}

export default SelectOptions;
