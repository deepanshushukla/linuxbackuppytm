/**
 * Created by deepanshushukla on 30/9/17.
 */
import React from 'react';
class AdCounter extends React.Component {

    constructor(props) {
        super(props);
        this.incrementAdCount = this.incrementAdCount.bind(this);
        this.decrementAdCount = this.decrementAdCount.bind(this);
        this.state = {
            adCount: 0
        };
    }

    incrementAdCount(e) {
        let adcount = this.state.adCount;
        if(this.props.maxcount > adcount) {
            this.setState({
                adCount: (adcount + 1)
            });
            this.props.changeAdCount(this.props.name.toLowerCase(),adcount+1);
        }
    }

    decrementAdCount(e) {
        let adcount = this.state.adCount;
        if (this.state.adCount > 0) {
            this.setState({
                adCount: (this.state.adCount - 1)
            });
            this.props.changeAdCount(this.props.name.toLowerCase(), adcount-1);
        }
    }

    render() {
        return (
            <div className="counter">
                <label>{this.props.name}</label>
                <div className="forminput">
                    <button className="icon" onClick={this.decrementAdCount}>-</button>
                        <span className="counter-score"> {this.state.adCount} </span>
                    <button className="icon" onClick={this.incrementAdCount}>+</button>
                </div>
            </div>
        );
    }
}
export default AdCounter;