import React from 'react';
import AdCounter from './adcounter';
import SelectOptions from './selectOptionsCmp';
import configData from '../config/configData';

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            totalprice: 0
        };
        this.getAdComponent = this.getAdComponent.bind(this);
        this.changeAdCount = this.changeAdCount.bind(this);
        this.getTotalPrice = this.getTotalPrice.bind(this);
        this.changeCustomer = this.changeCustomer.bind(this);
    }

    changeAdCount(key, count) {
        let {input} = configData;
        input.ad[key] = count;
        this.setState({totalprice: this.getTotalPrice(input)});

    }

    changeCustomer(customer) {
        let {input} = configData;
        input.customer = customer;
        this.setState({totalprice: this.getTotalPrice(input)});

    }

    getTotalPrice(input) {
        let {rules, rulesFunctions} = configData
            , total = 0, products = configData.adTypes
            , customer = rules[input.customer]
            , discounts = customer.discounts || {}
            , cartAds = Object.keys(input.ad)
            , inputCount
            , adRules;
        cartAds.forEach((ad) => {
            inputCount = input.ad[ad];
            adRules = discounts[ad];
            if (adRules) {
                Object.keys(adRules).forEach((ruleName) => {
                    let rule = adRules[ruleName];
                    total += rulesFunctions[ruleName]({...rule, inputCount, adType: ad, products});
                });
            }
            else {
                total += inputCount * products[ad].price;
            }
        });
        return total.toFixed(3);
    }

    getAdComponent(key, index) {
        let data = configData.adTypes[key];
        return <div className="formparent" key={index}><AdCounter changeAdCount={this.changeAdCount}  {...data}/></div>;
    }

    render() {

        return (
            <div className="mainContainer">
                <div className="formparent">
                    <label>Select Customer : </label>
                    <div className="forminput">
                        <SelectOptions value={configData.input.customer} changeCustomer={this.changeCustomer}
                                       list={configData.customers}/>
                    </div>

                </div>
                <div className="adtypecontainer">
                    <span className="adtypelabel">Select Ad Type</span>
                    { Object.keys(configData.adTypes).map(this.getAdComponent)}</div>
                    {parseInt(this.state.totalprice) !== 0 &&
                    <label className="total">TotalPrice : {this.state.totalprice}</label>}
            </div>
        )
    }
};

export default App;
