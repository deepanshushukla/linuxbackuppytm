/**
 * Created by deepanshushukla on 1/10/17.
 */
export const hasClass = (elem, className) =>{
    let classes = elem.className.split(' ');
    const idx = classes.indexOf(className);
    if (idx > -1) {
        return true;
    }
    else{
        return false;
    }
};