/**
 * Created by deepanshushukla on 1/10/17.
 */
let configData ={
    customers:['default','ford','apple','unilever','nike'],
     adTypes : {
        classic: {
            "name": "Classic",
            "price": 269.99,
            "maxcount":10
        },
        standout: {
            "name": "Standout",
            "price": 322.99,
            "maxcount":10
        },
        premium: {
            "name": "Premium",
            "price": 394.99,
            "maxcount":10
        }
    },
    rules:{
        nike: {
            discounts: {
                premium: {
                    _a_OrMore: {
                        minCount: 4,
                        price: 379.99
                    }

                }
            }
        },
        unilever: {
            discounts: {
                classic: {
                    _a_For_b_: {
                        a: 3,
                        b: 2

                    }
                }
            }
        },
        apple: {
            discounts: {
                standout: {
                    priceDrop: {
                        price: 299.99
                    }
                }
            }
        },
        ford:{
            discounts:{
                classic: {
                    _a_For_b_:{
                        a: 5,
                        b: 4

                    }
                },
                standout: {
                    priceDrop: {
                        price: 309.99
                    }
                },
                premium: {
                    _a_OrMore: {
                        minCount: 3,
                        price: 389.99
                    }
                }
            }
        },
        default: {
            discounts: {}
        }
    },
   rulesFunctions :{
        _a_OrMore: ({minCount, price, inputCount, adType, products}) => {
            if(inputCount >= minCount){
                return price * inputCount;
            }
            else {
                return products[adType].price * inputCount;
            }
        },
        _a_For_b_: ({a, b, inputCount,adType, products}) => {
            let first  = Math.floor(inputCount/a);
            let remainder = inputCount % a;
            let price =products[adType].price;
            return price*(first*b) + (remainder*price);
        },
        priceDrop: ({price, inputCount, adType}) => {
            return price * inputCount;
        }
    },
    input:{customer:'default',ad:{'classic':0,'standout':0,'premium':0} ,totalPrice:0}


};

export default configData;