import React, { Component } from 'react';
import Rating from './rating.jsx';
import {
 Link
} from 'react-router-dom';
class JobComponent extends Component {
  constructor (){
    super();
    //this.getFilteredDate =this.getFilteredDate.bind(this)
  }
  componentWillMount() {
  }
  getFilteredDate (date){
    //let dateObj =new Date():

  }
  render() {
    let {job} =this.props;
    let arrowClass =job.rank.split(' ')[0]=='Bottom'?'':'up'
    return (
      <Link to={`/detail/${job.JobId}`}>
      <div className="listing">
        <section className="user">
          <p className="designation"><b>{job.Designation}</b></p>
          <p className="companyName">{job.Company.Name}</p>
          <p className="companylocation">{job.Location}</p>
        </section>
        <span className="score">
                      <Rating score={job.score}/>
                    Job Match
                </span>
        <span className={`rank  ${arrowClass}`}>{job.rank}</span>
        <span className="status">
                  <p>Application Submitted</p>
                  <p>{job.status.date}</p>
            </span>
      </div>
      </Link>
    );
  }
}


export default JobComponent;
