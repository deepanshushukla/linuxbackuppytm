import React, { Component } from 'react';

class Trinagle extends Component {
  constructor (){
    super();
  }


  render() {
    let {rank} =this.props;
    let checkbottom =rank.split(' ')[0]=='Bottom'?'bottom':'up';
    console.log(checkbottom)
    return (
      <div className="triangle">
        <div className={`strip  ${checkbottom == 'up'?'active':''}`}>
          {checkbottom == 'up' &&
          <div className="content">{`You are among the ${rank} of the applicants for this job`}</div>
          }
        </div>
        <div className="strip"></div>
        <div className="strip"></div>
        <div className="strip"></div>
        <div className="strip"></div>
        <div className="strip"></div>
        <div className={`strip  ${checkbottom == 'bottom'?'active':''}`}>
          {checkbottom == 'bottom' &&
          <div className="content">{`You are among the ${rank} of the applicants for this job`}</div>
          }
        </div>
      </div>
    );
  }
}


export default Trinagle;
