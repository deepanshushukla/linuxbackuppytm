import React, { Component } from 'react';
import JobComponent from './jobcomponent.jsx';
import axios from 'axios';
class App extends Component {
  constructor (){
    super();
    this.createListing =this.createListing.bind(this)
    this.state ={
      listingData:{}
    }
  }
  componentWillMount() {
    let self =this
    axios.get('/listing.json')
      .then(function (response) {
        if(response) {
          self.setState({listingData:response.data.jobs});
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  }
  createListing(item ,index){
    let data =this.state.listingData[item].Job;
    return <JobComponent key={item} job={data}/>;

  }
  render() {
    return (
      <div className="listingcontainer">
        { Object.keys(this.state.listingData).map(this.createListing)}
     </div>
    );
  }
}


export default App;
