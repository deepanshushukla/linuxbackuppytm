import React, { Component } from 'react';

class Rating extends Component {
  constructor (){
    super();
    this.getDyanamicRating =this.getDyanamicRating.bind(this)
    this.state ={testArray:[0,1,2,3,4]}
  }
  getDyanamicRating(index){
    let {score} =this.props;
    let ratingClass =''
      if(score<2 ){
        if(index<2) {
          ratingClass ='lowrating'
        }
      }
      else {
        if(index<score) {
          ratingClass ='highrating';
        }

      }
        return <span key={index} className={ratingClass}></span>;

    }


render() {
    return (
      <div className="rating">
      {
        this.state.testArray.map(this.getDyanamicRating)
      }
    </div>
    );
  }
}


export default Rating;
