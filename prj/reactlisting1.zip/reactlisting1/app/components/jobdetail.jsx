import React, { Component } from 'react';
import axios from 'axios';
import Trinagle from "./triangle.jsx";
const Detail = ({job,dateFormatter,getProfiler}) => {
  console.log(dateFormatter)
  return  <div className="detailcontainer">
    <p className="designation">{job.jobDetail.designation}</p>
    <p className="company">{job.jobDetail.company}</p>
    <p className="experince">{job.jobDetail.minExperience}-{job.jobDetail.maxExperience} Years</p>
    <p className="location">{job.jobDetail.location}</p>
    <p className="activeon">
      <span>Recruiter Last active on</span>
      {
        dateFormatter(job.recruiterLastActiveDate)
      }
    </p>
    <Trinagle rank={job.rank}/>
    <div className="profilematcher">
      {Object.keys(job.profileMatchFlag).map(getProfiler)}
    </div>
  </div>
};
class DetailComponent extends Component {
  constructor() {
    super();
    this.state ={job:{}};
    this.dateFormatter =this.dateFormatter.bind(this)
    this.getProfiler =this.getProfiler.bind(this)
  }

  componentWillMount() {
    let self = this
    axios.get('/detail.json')
      .then(function (response) {
        if (response) {
          console.log(response)
          self.setState({job: response.data});
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  }
  dateFormatter(date){
    let mydate = new Date(date);
    let month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][mydate.getMonth()];
    return mydate.getDay()+' '+month + ' ' + mydate.getFullYear();
  }
  getProfiler(index){
    if(this.state.job.profileMatchFlag[index]=="1") {
      return <div key={index} className='profiledata active'>{index}</div>;
    }
    else{
      return <div key={index} className='profiledata disable'>{index}</div>;
    }
  }

  render() {
    return (
      <div>
          {Object.keys(this.state.job).length >0 && <Detail getProfiler ={this.getProfiler} dateFormatter={this.dateFormatter} job={this.state.job}/>}
      </div>
  )

  }
}


export default DetailComponent;
