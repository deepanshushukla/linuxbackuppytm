import React from 'react';
import ReactDOM from 'react-dom';
import {
  BrowserRouter as Router,
  Route,
} from 'react-router-dom';
import App from './components/App';
import DetailComponent from './components/jobdetail.jsx';
import './app.css';

ReactDOM.render(
  <Router>

    <div>
      <Route exact path="/" component={App} />
      <Route  path="/detail/:jobid" component={DetailComponent} />
    </div>

  </Router>,

  document.getElementById('app'));
